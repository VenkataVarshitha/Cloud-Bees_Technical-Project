import java.util.HashMap;
import java.util.Map;
class Train {
    private Map<String, String> seatAllocation;
    private Map<String, TrainTicket> ticketMap;

    public Train() {
        seatAllocation = new HashMap<>();
        ticketMap = new HashMap<>();
    }

    public void purchaseTicket(String from, String to, String firstName, String lastName, String email, double pricePaid, String seatSection) {
        String user = firstName + " " + lastName;
        String seat = assignSeat(seatSection);
        String receiptId = generateReceiptId();
        TrainTicket ticket = new TrainTicket(from, to, user, pricePaid, seatSection);
        seatAllocation.put(seat, user);
        ticketMap.put(receiptId, ticket);
        System.out.println("Ticket purchased successfully! Receipt ID: " + receiptId);
    }

    public void viewReceiptDetails(String receiptId) {
        if (ticketMap.containsKey(receiptId)) {
            TrainTicket ticket = ticketMap.get(receiptId);
            System.out.println(ticket);
        } else {
            System.out.println("Invalid receipt ID. Please try again.");
        }
    }

    public void viewSeatAllocationBySection(String section) {
        System.out.println("Seat Allocation for Section " + section + ":");
        for (Map.Entry<String, String> entry : seatAllocation.entrySet()) {
            if (entry.getKey().startsWith(section)) {
                System.out.println("Seat: " + entry.getKey() + ", User: " + entry.getValue());
            }
        }
    }

    public void removeUserFromTrain(String user) {
        boolean removed = false;
        for (Map.Entry<String, String> entry : seatAllocation.entrySet()) {
            if (entry.getValue().equals(user)) {
                seatAllocation.remove(entry.getKey());
                removed = true;
                break;
            }
        }
        if (removed) {
            System.out.println(user + " has been removed from the train.");
        } else {
            System.out.println(user + " is not currently on the train.");
        }
    }

    public void modifyUserSeat(String user, String newSeat) {
        boolean modified = false;
        for (Map.Entry<String, String> entry : seatAllocation.entrySet()) {
            if (entry.getValue().equals(user)) {
                seatAllocation.remove(entry.getKey());
                seatAllocation.put(newSeat, user);
                modified = true;
                break;
            }
        }
        if (modified) {
            System.out.println(user + "'s seat has been modified to " + newSeat);
        } else {
            System.out.println(user + " is not currently on the train.");
        }
    }

    private String assignSeat(String section) {
        int sectionCount = 0;
        for (String seat : seatAllocation.keySet()) {
            if (seat.startsWith(section)) {
                sectionCount++;
            }
        }
        return section + sectionCount;
    }

    private String generateReceiptId() {
        return "R" + (ticketMap.size() + 1);
    }
}

