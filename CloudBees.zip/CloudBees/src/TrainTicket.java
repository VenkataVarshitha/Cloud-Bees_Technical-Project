import java.util.Map;

class TrainTicket {
    private String from;
    private String to;
    private String user;
    private double pricePaid;
    private String seatSection;

    public TrainTicket(String from, String to, String user, double pricePaid, String seatSection) {
        this.from = from;
        this.to = to;
        this.user = user;
        this.pricePaid = pricePaid;
        this.seatSection = seatSection;
    }

    public String getFrom() {
        return from;
    }

    public String getTo() {
        return to;
    }

    public String getUser() {
        return user;
    }

    public double getPricePaid() {
        return pricePaid;
    }

    public String getSeatSection() {
        return seatSection;
    }

    @Override
    public String toString() {
        return "Receipt Details:\n" +
                "From: " + from + "\n" +
                "To: " + to + "\n" +
                "User: " + user + "\n" +
                "Price Paid: $" + pricePaid + "\n" +
                "Seat Section: " + seatSection;
    }
}

