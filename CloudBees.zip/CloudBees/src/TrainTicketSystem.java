public class TrainTicketSystem {
    public static void main(String[] args) {
        Train train = new Train();

        // Purchase a ticket
        train.purchaseTicket("London", "France", "John", "Doe", "johndoe@example.com", 20.0, "A");
        System.out.println();

        // View receipt details
        train.viewReceiptDetails("R1");
        System.out.println();

        // View seat allocation by section
        train.viewSeatAllocationBySection("A");
        System.out.println();

        // Remove a user from the train
        train.removeUserFromTrain("John Doe");
        System.out.println();

        // Modify a user's seat
        train.modifyUserSeat("John Doe", "A2");
        System.out.println();
    }
}